Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue

$databasePrefix = "SP2010"
$webAppName = "SPCHOT - Scenario04"
$webAppUrl = "scenario04.spchot.lab"
$appPoolName = "SharePoint Worker Process"
$contentDatabaseName = $databasePrefix + "_Content_Scenario04"
$contentDatabaseServerName = "SPContent"
$siteOwner = "SPCHOT\LabAdmin"
$siteName = "Scenario 04"
$siteTemplate = "STS#0"


# Create Web Application
$ap = New-SPAuthenticationProvider
New-SPWebApplication -Name $webAppName -Url "http://$webAppUrl" -HostHeader $webAppUrl -ApplicationPool $appPoolName -DatabaseName $contentDatabaseName -DatabaseServer $contentDatabaseServerName -Port 80 -AuthenticationProvider $ap

# Create Site Collection
New-SPSite -Url "http://$webAppUrl" -Name $siteName -OwnerAlias $siteOwner -Template $siteTemplate