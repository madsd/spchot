﻿using Microsoft.SharePoint.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Web;

namespace Scenario04
{
    public class BrowserOptimizer : IHttpModule
    {
        public void Dispose()
        {
            
        }

        private HttpApplication httpApplication;

        public void Init(HttpApplication context)
        {
            httpApplication = context;
            context.PreRequestHandlerExecute += new EventHandler(context_PreRequestHandlerExecute);
        }

        private void context_PreRequestHandlerExecute(object sender, EventArgs e)
        {
            using (SPMonitoredScope scope = new SPMonitoredScope("Optimizing browser experience for Firefox"))
            {
                if (httpApplication.Context.Request.UserAgent.Contains("Firefox"))
                {
                    TimeConsumingOperation();
                }
            }
        }

        private void TimeConsumingOperation()
        {
            Random rnd = new Random();
            int sleepTime = rnd.Next(300, 1800);
            Thread.Sleep(sleepTime);
        }
    }
}
