﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web.UI;
using System.Xml.Linq;
using Microsoft.SharePoint.Utilities;
using Scenario01.WebParts.Entities;
using Scenario01.Config.Global;
using Microsoft.SharePoint.Administration;

namespace Scenario01.WebParts.WebParts.FeedWebPart
{
    public partial class FeedWebPartUserControl : UserControl
    {
        private Uri feedUri = null;
        private List<FeedItem> feedItems = null;
        private FeedSettings feedSettings = null;

        public FeedWebPartUserControl()
        {
            feedSettings = SPFarm.Local.GetChild<FeedSettings>(Constants.FeedSettingsName);
            feedUri = new Uri(feedSettings.FeedUrl);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            feedItems = GetFeedItems();
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            if (feedItems != null || feedItems.Count == 0)
            {
                feedRepeater.DataSource = feedItems;
                feedRepeater.DataBind();
            } 
        }
        
        private List<FeedItem> GetFeedItems()
        {
            string response = null;

            using (SPMonitoredScope scope = new SPMonitoredScope("FeedWebPart.GetFeedItems"))
            {
                WebClient client = new WebClient();
                response = client.DownloadString(feedUri);
            }

            if (String.IsNullOrEmpty(response))
            {
                return new List<FeedItem>();
            }
            else
            {
                return GetFeedItemsFromXml(response);
            }
        }

        private List<FeedItem> GetFeedItemsFromXml(string response)
        {
            List<FeedItem> feedItemsList = new List<FeedItem>();
            XDocument xDoc = XDocument.Parse(response);
            XElement channelElement = (from channels in xDoc.Descendants("channel") select channels).First();
            IEnumerable<XElement> itemsCollection = channelElement.Elements("item");

            foreach (XElement item in itemsCollection)
            {
                FeedItem feedItem = new FeedItem();
                feedItem.Title = item.Element("title").Value;
                feedItem.Link = new Uri(item.Element("link").Value);
                feedItem.Published = DateTime.Parse(item.Element("pubDate").Value);
                feedItemsList.Add(feedItem);

                if (feedItemsList.Count == 10)
                    break;
            }

            return feedItemsList;
        }

        protected string GetTitle(object dataItem)
        {
            FeedItem item = dataItem as FeedItem;
            
            if(item != null)
                return item.Title;
            else
                return "Error";
        }

        protected string GetLink(object dataItem)
        {
            FeedItem item = dataItem as FeedItem;

            if (item != null)
                return item.Link.AbsoluteUri;
            else
                return "Error";
        }

        protected string GetDate(object dataItem)
        {
            FeedItem item = dataItem as FeedItem;

            if (item != null)
                return item.Published.ToShortTimeString();
            else
                return "Error";
        }
    }
}
