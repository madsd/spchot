﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Scenario01.WebParts.Entities
{
    public class FeedItem
    {
        public string Title { get; set; }
        public Uri Link { get; set; }
        public DateTime Published { get; set; }
    }
}
