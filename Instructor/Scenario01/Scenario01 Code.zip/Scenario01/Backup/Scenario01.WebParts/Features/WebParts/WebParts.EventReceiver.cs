using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using Microsoft.SharePoint.Publishing;
using Microsoft.SharePoint.WebPartPages;
using System.Web.UI.WebControls.WebParts;
using Scenario01.WebParts.WebParts.FeedWebPart;

namespace Scenario01.WebParts.Features.WebParts
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("7da64da9-abfc-439e-9de7-93335822829f")]
    public class WebPartsEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPSite site = properties.Feature.Parent as SPSite;

            if (site != null)
            {
                PublishingWeb pubWeb = PublishingWeb.GetPublishingWeb(site.RootWeb);
                SPFile startPageFile = pubWeb.DefaultPage;
                startPageFile.CheckOut();
                
                SPLimitedWebPartManager webpartManager = startPageFile.GetLimitedWebPartManager(PersonalizationScope.Shared); //do not dispose, rootweb
                webpartManager.AddWebPart(new FeedWebPart() { Title = "SharePoint Team Blog"}, "TopColumnZone", 0);
                startPageFile.CheckIn("", SPCheckinType.MajorCheckIn);
                startPageFile.Publish("");
            }
        }
    }
}
