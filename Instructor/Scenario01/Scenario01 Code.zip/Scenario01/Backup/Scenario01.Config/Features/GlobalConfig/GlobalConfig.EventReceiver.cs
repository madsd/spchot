using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using Microsoft.SharePoint.Administration;
using Scenario01.Config.Global;

namespace Scenario01.Config.Features.GlobalConfig
{

    [Guid("8ec5a06b-1f91-4cc6-8a1a-b0ba989556e5")]
    public class GlobalConfigEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPFarm farm = SPFarm.Local;

            if (farm != null)
            {
                FeedSettings settings = new FeedSettings(Constants.FeedSettingsName, farm);
                settings.Update();
            }
        }

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPFarm farm = SPFarm.Local;

            if (farm != null)
            {
                FeedSettings settings = farm.GetChild<FeedSettings>(Constants.FeedSettingsName);
                settings.Delete();
                settings.Unprovision();
                settings.Uncache();
            }
        }
    }
}
