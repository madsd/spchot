﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Administration;
using System.Runtime.InteropServices;

namespace Scenario01.Config.Global
{
    [GuidAttribute("8375F75D-CEC2-4918-B596-A03E81C4541B")]
    public class FeedSettings : SPPersistedObject
    {
        [Persisted]
        private string feedUrl = "http://localhost:31000/SharePointTeamBlog.xml";
        
        public string FeedUrl
        {
            get
            {
                return feedUrl;
            }
            set
            {
                feedUrl = value;
            }
        }

        public FeedSettings() : base() { }
        public FeedSettings(string name, SPPersistedObject parent): base(name, parent) { }
        public FeedSettings(string name, SPPersistedObject parent, Guid id) : base(name, parent, id) { }
    }
}
