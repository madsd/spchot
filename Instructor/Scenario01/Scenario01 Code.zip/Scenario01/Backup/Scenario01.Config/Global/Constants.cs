﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Scenario01.Config.Global
{
    public static class Constants
    {
        public static string FeedSettingsName { get { return "GlobalFeedSettings"; } }
    }
}
