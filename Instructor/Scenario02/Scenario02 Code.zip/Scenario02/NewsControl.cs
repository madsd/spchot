﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Scenario02
{ 
    public class NewsControl : WebControl
    {
        protected override void RenderContents(HtmlTextWriter output)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                // Get Server Name
                using (SPMonitoredScope scope = new SPMonitoredScope("Scenario02 News Control Database Fetch"))
                {
                    SqlConnection conn = null;
                    SqlDataReader rdr = null;

                    try
                    {
                        conn = new SqlConnection("Server=SPContent;Database=AdventureWorks2012;Integrated Security=SSPI");
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("[dbo].[uspGetTransactionHistory]", conn);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@TopRows", SqlDbType.Int).Value = 4;

                        rdr = cmd.ExecuteReader();
                    }
                    finally
                    {
                        if (conn != null)
                        {
                            conn.Close();
                        }
                        if (rdr != null)
                        {
                            rdr.Close();
                        }
                    }
                }
            });
        }
    }
}
