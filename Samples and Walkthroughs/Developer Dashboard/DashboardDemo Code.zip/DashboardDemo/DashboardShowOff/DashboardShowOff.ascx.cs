﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.ComponentModel;
using System.Threading;
using System.Web.UI.WebControls.WebParts;

namespace Scenario.DashboardShowOff
{
    [ToolboxItemAttribute(false)]
    public partial class DashboardShowOff : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public DashboardShowOff()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
        }

        #region Simple Scope
        protected void Button1_Click(object sender, EventArgs e)
        {
            using (SPMonitoredScope scope = new SPMonitoredScope("SPCHOT Simple Monitored Scope"))
            {
                // Here goes my code
                TimeConsumingOperation();
                lblOutput.Text = "Clicked: " + DateTime.Now.ToLongTimeString();
            }
        }
        #endregion

        #region Nested Scope
        protected void Button2_Click(object sender, EventArgs e)
        {
            using (SPMonitoredScope scope = new SPMonitoredScope("SPCHOT Outer Monitored Scope"))
            {
                // Here goes my code
                TimeConsumingOperation();

                using (SPMonitoredScope subscope = new SPMonitoredScope("SPCHOT Inner Monitored Scope"))
                {
                    // Here goes my special code
                    TimeConsumingOperation();
                    lblOutput.Text = "Clicked: " + DateTime.Now.ToLongTimeString();
                }
            }
        }
        #endregion

        #region Timed Scope
        protected void Button3_Click(object sender, EventArgs e)
        {
            uint timeOut = 800;
            SPExecutionTimeCounter timer = new SPExecutionTimeCounter(timeOut);
            
            using (SPMonitoredScope scope = new SPMonitoredScope("SPCHOT Monitored Scope with timeout", timeOut, timer))
            {
                // Here goes my code
                TimeConsumingOperation();
                if (timer.ValueIsExcessive)
                {
                    lblOutput.Text = "Too slow... Clicked: " + DateTime.Now.ToLongTimeString();
                    SPCriticalTraceCounter.AddDataToScope(1000, "SPCHOT", 1, "TimeConsumingOperation took " + timer.Value);
                    /*
                     1 - Critical
                     4 - Exception
                     6 - Assert
                     8 - Warning
                     10 - Unexpected
                     15 - Monitorable
                     */
                }
                else
                {
                    lblOutput.Text = "Clicked: " + DateTime.Now.ToLongTimeString();
                }
            }        
        }
        #endregion

        private void TimeConsumingOperation()
        {
            Random rnd = new Random();
            int sleepTime = rnd.Next(300, 2300);
            Thread.Sleep(sleepTime);
        }

    }
}
