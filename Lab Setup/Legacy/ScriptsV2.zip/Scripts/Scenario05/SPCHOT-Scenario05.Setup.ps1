Write-Host "- Installing Scenario 05"
Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue

Write-Host " - Creating DNS entry"

$IPAddress = "192.168.2.3"
$DnsServer = "DCSQL"
$DnsZoneName = "contoso.com"
$ARecordName = "scenario05"

$record = Invoke-Command -ComputerName $DnsServer -ScriptBlock {Get-DnsServerResourceRecord -ZoneName $args[1] -RRType A | ? HostName -eq $args[0]} -ArgumentList $ARecordName, $DnsZoneName
if ($record -eq $null)
{
    Write-Host " - Adding DNS Record" 
    Invoke-Command -ComputerName $DnsServer -ScriptBlock {Add-DnsServerResourceRecordA -Name $args[0] -ZoneName $args[1] -IPv4Address $args[2]} -ArgumentList $ARecordName, $DnsZoneName, $IPAddress
}
else
{
    Write-Host " - Existing DNS Record found" 
}

$rootPath = $PSScriptRoot
if ($rootPath -eq "")
{
	$rootPath = (Get-Location).Path
}

#Setup Web Application to host scenario application
Write-Host " - Creating web application for scenario"
$WebAppName = "SPCHOT - Scenario 05"
$AppPoolName = "SharePoint - intranet.contoso.com80"
$HostHeader = "scenario05.contoso.com"
$WebApplicationUrl = "http://" + $HostHeader
$ContentDatabaseName = "SP2013_Content_SPCHOT_Scenario05"
$ContentDatabaseServerName = "SPSQL"

$ap = New-SPAuthenticationProvider
New-SPWebApplication -Name $WebAppName -ApplicationPool $AppPoolName -Url $WebApplicationUrl -HostHeader $HostHeader -DatabaseName $ContentDatabaseName -DatabaseServer $contentDatabaseServerName -Port 80 -AuthenticationProvider $ap | Out-Null

$siteUrl = "http://scenario05.contoso.com/"
$SiteTemplate = "SRCHCEN#0"
$SiteLcid = 1033
$SiteOwner = "CONTOSO\administrator"
$SiteName = "Contoso Search Center"

Write-Host ([String]::Format("Creating new site collection at URL {0}...", $SiteUrl)) -NoNewline
$NewSite = New-SPSite -Url $siteUrl -Language $SiteLcid -Template $SiteTemplate -Name $SiteName -OwnerAlias $SiteOwner
Write-Host "Done!"

$solutionPackageName = "Scenario05.wsp"

$path = $rootPath
$solutionPath = $path + "\" + $solutionPackageName
Add-SPSolution -LiteralPath $solutionPath | Out-Null
Install-SPSolution -Identity $solutionPackageName -GACDeployment | Out-Null

$deployed = Get-SPSolution -Identity $solutionPackageName | SELECT Deployed

while (!$deployed.Deployed)
{
    $deployed = Get-SPSolution -Identity $solutionPackageName | SELECT Deployed
    Write-Host "." -NoNewline
    Start-Sleep -Seconds 2
}
Write-Host
Write-Host "Finished Installing solution"

Enable-SPFeature -Identity "Scenario05_Scenario05DesignElements" -Url $siteUrl | Out-Null

Write-Host "Done installing Scenario 05"