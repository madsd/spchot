Write-Host "- Installing Scenario 04"
Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue

Write-Host " - Creating DNS entry"
dnscmd spdc01.contoso.com /recordadd contoso.com. scenario04.contoso.com. A 192.168.197.2 

#Setup Web Application to host scenario application
Write-Host " - Creating web application for scenario"
$WebAppName = "SPCHOT - Scenario 04"
$AppPoolName = "SharePoint Web Applications"
$HostHeader = "scenario04.contoso.com"
$WebApplicationUrl = "http://" + $HostHeader
$ContentDatabaseName = "SP2013_Content_SPCHOT_Scenario04"
$ContentDatabaseServerName = "SPSQL01"

$ap = New-SPAuthenticationProvider
New-SPWebApplication -Name $WebAppName -ApplicationPool $AppPoolName  -HostHeader $HostHeader -DatabaseName $ContentDatabaseName -DatabaseServer $contentDatabaseServerName -Port 80 -AuthenticationProvider $ap | Out-Null

$siteUrl = "http://scenario04.contoso.com/"
$SiteTemplate = "STS#0"
$SiteLcid = 1033
$SiteOwner = "CONTOSO\administrator"
$SiteName = "Contoso Team Site"

Write-Host ([String]::Format("Creating new site collection at URL {0}...", $SiteUrl)) -NoNewline
$NewSite = New-SPSite -Url $siteUrl -Language $SiteLcid -Template $SiteTemplate -Name $SiteName -OwnerAlias $SiteOwner
Write-Host "Done!"


$solutionPackageName = "Scenario04.wsp"

$path = Split-Path $MyInvocation.MyCommand.Path | Get-Item
$solutionPath = $path.FullName + "\" + $solutionPackageName
Add-SPSolution -LiteralPath $solutionPath | Out-Null
Install-SPSolution -Identity $solutionPackageName -GACDeployment | Out-Null

$deployed = Get-SPSolution -Identity $solutionPackageName | SELECT Deployed

while (!$deployed.Deployed)
{
    $deployed = Get-SPSolution -Identity $solutionPackageName | SELECT Deployed
    Write-Host "." -NoNewline
    Start-Sleep -Seconds 2
}
Write-Host
Write-Host "Finished Installing solution"

[Microsoft.SharePoint.Administration.SPWebService] $service =[Microsoft.SharePoint.Administration.SPWebService]::ContentService

$configMod = New-Object Microsoft.SharePoint.Administration.SPWebConfigModification
$configMod.Path = "configuration/system.webServer/modules"
$configMod.Name = "add[@name='Scenario04']"
$configMod.Sequence = 0
$configMod.Owner = "Scenario04"
$configMod.Type = 0 # EnsureNode
$configMod.Value = "<add name='Scenario04' type='Scenario04.BrowserOptimizer, Scenario04, Version=1.0.0.0, Culture=neutral, PublicKeyToken=24c39aff80c1b745' />"

# Apply to Individual Web Application
$webApp = Get-SPWebApplication http://scenario04.contoso.com
$webApp.WebConfigModifications.Add($configMod)
$webApp.Update()

$service.ApplyWebConfigModifications()

Write-Host "Done installing Scenario 04"