Write-Host "- Installing Scenario 05"
Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue

Write-Host " - Creating DNS entry"
dnscmd spdc01.contoso.com /recordadd contoso.com. scenario05.contoso.com. A 192.168.197.2 

#Setup Web Application to host scenario application
Write-Host " - Creating web application for scenario"
$WebAppName = "SPCHOT - Scenario 05"
$AppPoolName = "SharePoint Web Applications"
$HostHeader = "scenario05.contoso.com"
$WebApplicationUrl = "http://" + $HostHeader
$ContentDatabaseName = "SP2013_Content_SPCHOT_Scenario05"
$ContentDatabaseServerName = "SPSQL01"

$ap = New-SPAuthenticationProvider
New-SPWebApplication -Name $WebAppName -ApplicationPool $AppPoolName  -HostHeader $HostHeader -DatabaseName $ContentDatabaseName -DatabaseServer $contentDatabaseServerName -Port 80 -AuthenticationProvider $ap | Out-Null

$siteUrl = "http://scenario05.contoso.com/"
$SiteTemplate = "SRCHCEN#0"
$SiteLcid = 1033
$SiteOwner = "CONTOSO\administrator"
$SiteName = "Contoso Search Center"

Write-Host ([String]::Format("Creating new site collection at URL {0}...", $SiteUrl)) -NoNewline
$NewSite = New-SPSite -Url $siteUrl -Language $SiteLcid -Template $SiteTemplate -Name $SiteName -OwnerAlias $SiteOwner
Write-Host "Done!"


$solutionPackageName = "Scenario05.wsp"

$path = Split-Path $MyInvocation.MyCommand.Path | Get-Item
$solutionPath = $path.FullName + "\" + $solutionPackageName
Add-SPSolution -LiteralPath $solutionPath | Out-Null
Install-SPSolution -Identity $solutionPackageName -GACDeployment | Out-Null

$deployed = Get-SPSolution -Identity $solutionPackageName | SELECT Deployed

while (!$deployed.Deployed)
{
    $deployed = Get-SPSolution -Identity $solutionPackageName | SELECT Deployed
    Write-Host "." -NoNewline
    Start-Sleep -Seconds 2
}
Write-Host
Write-Host "Finished Installing solution"

Enable-SPFeature -Identity "Scenario05_Scenario05DesignElements" -Url $siteUrl | Out-Null

Write-Host "Done installing Scenario 05"